package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class AddMedicineActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.add_medicine);


        MaterialButton resetButton = findViewById(R.id.reset_button);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearForm();
            }
        });

        MaterialButton submitButton = findViewById(R.id.submit_button);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveMedicine();
            }
        });

    }

    private void clearForm() {

        ((TextInputEditText) findViewById(R.id.medName_input)).setText("");
        ((TextInputEditText) findViewById(R.id.medDesc_input)).setText("");
        ((TextInputEditText) findViewById(R.id.medPrice_input)).setText("");
    }

    private void saveMedicine() {
        // Get references to input fields
        TextInputEditText medicineName = findViewById(R.id.medName_input);
        TextInputEditText medicineDescription = findViewById(R.id.medDesc_input);
        TextInputEditText medicinePrice = findViewById(R.id.medPrice_input);

        // Get input text as strings
        String med_name = medicineName.getText().toString().trim();
        String med_desc = medicineDescription.getText().toString().trim();
        String med_price_str = medicinePrice.getText().toString().trim();

        // Validate input fields
        if (med_name.isEmpty()) {
            medicineName.setError("Please enter a medicine name");
            medicineName.requestFocus();
            return;
        }

        if (med_desc.isEmpty()) {
            medicineDescription.setError("Please enter a medicine description");
            medicineDescription.requestFocus();
            return;
        }

        if (med_price_str.isEmpty()) {
            medicinePrice.setError("Please enter a price");
            medicinePrice.requestFocus();
            return;
        }

        double med_price;
        try {
            med_price = Double.parseDouble(med_price_str);
        } catch (NumberFormatException e) {
            medicinePrice.setError("Please enter a valid price");
            medicinePrice.requestFocus();
            return;
        }

        // Ensure the price is not negative or zero
        if (med_price <= 0) {
            medicinePrice.setError("Price must be greater than zero");
            medicinePrice.requestFocus();
            return;
        }

        // If validation passes, save the medicine to the database
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.addMedicine(med_name, med_desc, med_price);

        // Show success message
        Toast.makeText(this, "Medicine added successfully", Toast.LENGTH_SHORT).show();

        setResult(RESULT_OK);
        finish();
    }


}
