package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class PatientsAdapter extends RecyclerView.Adapter<PatientsAdapter.PatientViewHolder> {
    private Context context;
    private List<Patient> patients;
    private OnPatientListener onPatientListener;


    public PatientsAdapter(Context context, List<Patient> patients, OnPatientListener onPatientListener) {
        this.context = context;
        this.patients = patients;
        this.onPatientListener = onPatientListener;
    }

    @NonNull
    @Override
    public PatientViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.patient_item, parent, false);
        return new PatientViewHolder(view, onPatientListener);
    }

    @Override
    public void onBindViewHolder(@NonNull PatientViewHolder holder, int position) {
        Patient patient = patients.get(position);
        holder.tvPatientName.setText(patient.getName());
    }

    @Override
    public int getItemCount() {
        return patients.size();
    }

    public void updateList(List<Patient> newList) {
        patients = new ArrayList<>(newList);
        notifyDataSetChanged();
    }

    class PatientViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvPatientName;
        Button btnDeletePatient;
        OnPatientListener onPatientListener;

        public PatientViewHolder(@NonNull View itemView, OnPatientListener onPatientListener) {
            super(itemView);
            tvPatientName = itemView.findViewById(R.id.tv_patient_name);
            btnDeletePatient = itemView.findViewById(R.id.btn_delete_patient);
            this.onPatientListener = onPatientListener;
            itemView.setOnClickListener(this);
            btnDeletePatient.setOnClickListener(v -> {
                if (onPatientListener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        onPatientListener.onDeleteClick(position);
                    }
                }
            });
        }

        @Override
        public void onClick(View v) {
            onPatientListener.onPatientClick(getAdapterPosition());
        }
    }

    interface OnPatientListener {
        void onPatientClick(int position);
        void onDeleteClick(int position);
    }

    public void filter(String text) {
        List<Patient> filteredList = new ArrayList<>();
        for (Patient patient : patients) {  // Assume patientList contains all patients
            if (patient.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(patient);
            }
        }
        this.patients = filteredList;
        notifyDataSetChanged();
    }
}
