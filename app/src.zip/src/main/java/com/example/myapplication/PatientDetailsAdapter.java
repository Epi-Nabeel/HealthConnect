package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PatientDetailsAdapter extends RecyclerView.Adapter<PatientDetailsAdapter.PatientViewHolder> {

    private List<Patient> patientDetails;

    public PatientDetailsAdapter(List<Patient> patientDetails) {
        this.patientDetails = patientDetails;
    }

    @NonNull
    @Override
    public PatientViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.patient_details_item, parent, false);
        return new PatientViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PatientViewHolder holder, int position) {
        Patient patient = patientDetails.get(position);
        holder.nameTextView.setText(patient.getName());
        holder.dobTextView.setText(patient.getDateOfBirth());
        holder.genderTextView.setText(patient.getGender());
        holder.phoneTextView.setText(patient.getPhoneNumber());
        holder.emailTextView.setText(patient.getEmail());
        holder.addressTextView.setText(patient.getAddress());
        holder.emergencyContactTextView.setText(patient.getEmergencyContact());
    }

    @Override
    public int getItemCount() {
        return patientDetails.size();
    }

    public void updateData(List<Patient> newData) {
        this.patientDetails.clear();
        this.patientDetails.addAll(newData);
        notifyDataSetChanged();
    }

    static class PatientViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView, dobTextView, genderTextView, phoneTextView, emailTextView, addressTextView, emergencyContactTextView;

        public PatientViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.patientNameTextView);
            dobTextView = itemView.findViewById(R.id.patientDOBTextView);
            genderTextView = itemView.findViewById(R.id.patientGenderTextView);
            phoneTextView = itemView.findViewById(R.id.patientPhoneNumberTextView);
            emailTextView = itemView.findViewById(R.id.patientEmailTextView);
            addressTextView = itemView.findViewById(R.id.patientAddressTextView);
            emergencyContactTextView = itemView.findViewById(R.id.patientEmergencyContactTextView);
        }
    }
}

