package com.example.myapplication;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddPatientActivity extends AppCompatActivity {

    private TextInputEditText patientFirstname;
    private TextInputEditText patientLastname;
    private TextInputEditText dateOfBirth;
    private TextInputEditText phoneNumber;
    private TextInputEditText email;
    private TextInputEditText phn;
    private TextInputEditText patientAddress;
    private TextInputEditText PatientEmergencyContact;
    private RadioGroup genderGroup;
    private RadioButton maleRadio;
    private RadioButton femaleRadio;
    private RadioButton otherRadio;
    private MaterialButton saveButton;
    private MaterialButton resetButton;
    String gender;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_patient);

        patientFirstname = findViewById(R.id.patient_FirstName_input);
        patientLastname = findViewById(R.id.patient_LastName_input);
        dateOfBirth = findViewById(R.id.dob_input);
        email = findViewById(R.id.email_input);
        phoneNumber = findViewById(R.id.phone_input);
        phn = findViewById(R.id.phn_input);
        patientAddress = findViewById(R.id.address_input);
        PatientEmergencyContact = findViewById(R.id.emergency_contact_input);
        genderGroup = findViewById(R.id.gender_group);
        maleRadio = findViewById(R.id.male_radio);
        femaleRadio = findViewById(R.id.female_radio);
        otherRadio = findViewById(R.id.other_radio);
        saveButton = findViewById(R.id.save_button);
        resetButton = findViewById(R.id.reset_button);

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        dateOfBirth.setOnClickListener(v -> {

            new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                // Update the calendar and set the selected date in the input
                calendar.set(year, month, dayOfMonth);
                dateOfBirth.setText(dateFormat.format(calendar.getTime()));
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int selectedGender = genderGroup.getCheckedRadioButtonId();
                if(selectedGender == maleRadio.getId()){
                    gender = "Male";
                } else if (selectedGender == femaleRadio.getId()) {
                    gender = "Female";
                }
                else if (selectedGender == otherRadio.getId()){
                    gender ="Other";
                }
                else {
                    gender="";
                }

                savePatient();
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearForm();
            }
        });



    }

    private void savePatient(){

        String patient_first_name = patientFirstname.getText().toString();
        String patient_last_name = patientLastname.getText().toString();
        String date_of_birth = dateOfBirth.getText().toString();
        String phone_number = phoneNumber.getText().toString();
        String eMail = email.getText().toString();
        String personal_health_number = phn.getText().toString();
        String address = patientAddress.getText().toString();
        String emContact = PatientEmergencyContact.getText().toString();

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.addPatient(patient_first_name, patient_last_name, date_of_birth,gender,phone_number,eMail, address,emContact);


        if (patient_first_name.isEmpty() || patient_last_name.isEmpty() || date_of_birth.isEmpty() ||
                phone_number.isEmpty() || eMail.isEmpty() || address.isEmpty() || emContact.isEmpty()) {
            Toast.makeText(this, "Please fill in all the required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        else if (gender.isEmpty()) {
            Toast.makeText(this, "Please select a gender", Toast.LENGTH_SHORT).show();
            return;
        }

        else {
            Toast.makeText(this, "Patient added successfully", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        }

    }

    private void clearForm() {
        ((TextInputEditText) findViewById(R.id.patient_FirstName_input)).setText("");
        ((TextInputEditText) findViewById(R.id.patient_LastName_input)).setText("");
        ((TextInputEditText) findViewById(R.id.dob_input)).setText("");
        ((TextInputEditText) findViewById(R.id.phone_input)).setText("");
        ((TextInputEditText) findViewById(R.id.email_input)).setText("");
        ((TextInputEditText) findViewById(R.id.phn_input)).setText("");
        ((TextInputEditText) findViewById(R.id.address_input)).setText("");
        ((TextInputEditText) findViewById(R.id.emergency_contact_input)).setText("");
    }
}
