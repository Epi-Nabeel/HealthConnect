package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;

public class MedicineListActivity extends AppCompatActivity {


    private RecyclerView recyclerView;
    private MedicineAdapter adapter;
    private List<Medicine> medicineList;
    private DatabaseHelper dbHelper;
    private MaterialButton addMedicine;
    private ActivityResultLauncher<Intent> addMedicineLauncher;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine_list);

        // ImageButton Click Handlers
        ImageButton btnPatientRecordsImg = findViewById(R.id.btn_patient_records);
        btnPatientRecordsImg.setOnClickListener(view -> {
            Intent intent = new Intent(MedicineListActivity.this, PatientsActivity.class);
            startActivity(intent);
        });

        ImageButton btnConsultationImg = findViewById(R.id.btn_consultation);
        btnConsultationImg.setOnClickListener(view -> {
            Intent intent = new Intent(MedicineListActivity.this, ConsultationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnMedicalTrackingImg = findViewById(R.id.btn_medical_tracking);
        btnMedicalTrackingImg.setOnClickListener(view -> {
            Intent intent = new Intent(MedicineListActivity.this, MedicationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnAppointmentsImg = findViewById(R.id.btn_appointments);
        btnAppointmentsImg.setOnClickListener(view -> {
            Intent intent = new Intent(MedicineListActivity.this, AppointmentsActivity.class);
            startActivity(intent);
        });

        ImageButton btnReportsImg = findViewById(R.id.btn_reports);
        btnReportsImg.setOnClickListener(view -> {
            Intent intent = new Intent(MedicineListActivity.this, MedicineListActivity.class);
            startActivity(intent);
        });

        addMedicineLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        List<Medicine> medicine = dbHelper.getAllGeneralMedicines();
                        adapter.updateList(medicine);
                    }
                }
        );

        addMedicine = findViewById(R.id.btnAddMedicine);

        addMedicine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MedicineListActivity.this, AddMedicineActivity.class);
                addMedicineLauncher.launch(intent);
            }
        });


        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dbHelper = new DatabaseHelper(this);

        loadMedicines();
    }

    private void loadMedicines() {
        medicineList = dbHelper.getAllGeneralMedicines();
        if (medicineList != null && !medicineList.isEmpty()) {
            adapter = new MedicineAdapter(this, medicineList);
            recyclerView.setAdapter(adapter);
        }
    }


}
