package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.home_page);

        // CardView Buttons
        CardView btnPatientRecords = findViewById(R.id.homepage_btnPatientRecords);
        btnPatientRecords.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, PatientsActivity.class);
            startActivity(intent);
        });

        CardView btnConsultation = findViewById(R.id.homepage_btnConsultation);
        btnConsultation.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ConsultationHistoryActivity.class);
            startActivity(intent);
        });

        CardView btnMedicalTracking = findViewById(R.id.homepage_btnMedicalTracking);
        btnMedicalTracking.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, MedicationHistoryActivity.class);
            startActivity(intent);
        });

        CardView btnAppointments = findViewById(R.id.homepage_btnAppointments);
        btnAppointments.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AppointmentsActivity.class);
            startActivity(intent);
        });

        CardView btnReports = findViewById(R.id.homepage_btnReport);
        btnReports.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, MedicineListActivity.class);
            startActivity(intent);
        });

        // ImageButton Click Handlers
        ImageButton btnPatientRecordsImg = findViewById(R.id.btn_patient_records);
        btnPatientRecordsImg.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, PatientsActivity.class);
            startActivity(intent);
        });

        ImageButton btnConsultationImg = findViewById(R.id.btn_consultation);
        btnConsultationImg.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ConsultationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnMedicalTrackingImg = findViewById(R.id.btn_medical_tracking);
        btnMedicalTrackingImg.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, MedicationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnAppointmentsImg = findViewById(R.id.btn_appointments);
        btnAppointmentsImg.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AppointmentsActivity.class);
            startActivity(intent);
        });

        ImageButton btnReportsImg = findViewById(R.id.btn_reports);
        btnReportsImg.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, MedicineListActivity.class);
            startActivity(intent);
        });

        // Window Insets for Edge-to-Edge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}