package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PatientDetailsActivity extends AppCompatActivity {

    private int patientId;
    private String patientName;
    private RecyclerView patientDetailsRecyclerView, consultationHistoryRecyclerView, medicationLogRecyclerView;
    private PatientDetailsAdapter patientDetailsAdapter;
    private ConsultationAdapter consultationAdapter;
    private MedicationAdapter medicationAdapter;
    private DatabaseHelper dbHelper;
    private MaterialButton consultationButton;
    private MaterialButton medicationButton;
    private MaterialButton editButton;

    private ActivityResultLauncher<Intent> editPatientLauncher;
    private ActivityResultLauncher<Intent> addConsultationLauncher;
    private ActivityResultLauncher<Intent> addMedicationLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.patient_details);

        // ImageButton Click Handlers
        ImageButton btnPatientRecordsImg = findViewById(R.id.btn_patient_records);
        btnPatientRecordsImg.setOnClickListener(view -> {
            Intent intent = new Intent(PatientDetailsActivity.this, PatientsActivity.class);
            startActivity(intent);
        });

        ImageButton btnConsultationImg = findViewById(R.id.btn_consultation);
        btnConsultationImg.setOnClickListener(view -> {
            Intent intent = new Intent(PatientDetailsActivity.this, ConsultationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnMedicalTrackingImg = findViewById(R.id.btn_medical_tracking);
        btnMedicalTrackingImg.setOnClickListener(view -> {
            Intent intent = new Intent(PatientDetailsActivity.this, MedicationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnAppointmentsImg = findViewById(R.id.btn_appointments);
        btnAppointmentsImg.setOnClickListener(view -> {
            Intent intent = new Intent(PatientDetailsActivity.this, AppointmentsActivity.class);
            startActivity(intent);
        });

        ImageButton btnReportsImg = findViewById(R.id.btn_reports);
        btnReportsImg.setOnClickListener(view -> {
            Intent intent = new Intent(PatientDetailsActivity.this, MedicineListActivity.class);
            startActivity(intent);
        });

        addConsultationLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        List<Consultation> consultations = dbHelper.getConsultationsByPatientId(patientId);
                        consultationAdapter.updateData(consultations);
                    }
                }
        );

        addMedicationLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        List<Medication> medications = dbHelper.getMedicationsByPatientId(patientId);
                        medicationAdapter.updateData(medications);
                    }
                }
        );

        editPatientLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadPatientData(patientId);
                    }
                }
        );

        consultationButton = findViewById(R.id.pdCons_button);
        medicationButton = findViewById(R.id.pdMedication_button);
        editButton = findViewById(R.id.pdEdit_button);

        // Initialize Database Helper
        dbHelper = new DatabaseHelper(this);

        // Retrieve the patient ID passed from the previous activity
        patientId = getIntent().getIntExtra("patient_id", -1);

        // Initialize RecyclerViews
        setupRecyclerViews();

        // Load patient details, consultation history, and medication logs
        loadPatientData(patientId);

        consultationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PatientDetailsActivity.this, AddConsultationActivity.class);
                intent.putExtra("patient_id", patientId);
                intent.putExtra("patient_name", patientName);
                addConsultationLauncher.launch(intent);
            }
        });

        medicationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PatientDetailsActivity.this, AddMedicationActivity.class);
                intent.putExtra("patient_id", patientId);
                intent.putExtra("patient_name", patientName);
                addMedicationLauncher.launch(intent);
            }
        });

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PatientDetailsActivity.this, EditPatientDetailsActivity.class);
                intent.putExtra("patient_id", patientId);
                intent.putExtra("patient_name", patientName);
                editPatientLauncher.launch(intent);
            }
        });
    }

    private void setupRecyclerViews() {
        patientDetailsRecyclerView = findViewById(R.id.patientDetailsRecyclerView);
        consultationHistoryRecyclerView = findViewById(R.id.consultationHistoryRecyclerView);
        medicationLogRecyclerView = findViewById(R.id.medicationLogRecyclerView);

        patientDetailsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        consultationHistoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        medicationLogRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize Adapters
        patientDetailsAdapter = new PatientDetailsAdapter(new ArrayList<>());
        consultationAdapter = new ConsultationAdapter(this, new ArrayList<>(), false);
        medicationAdapter = new MedicationAdapter(this, new ArrayList<>(), false);

        // Set Adapters to RecyclerViews
        patientDetailsRecyclerView.setAdapter(patientDetailsAdapter);
        consultationHistoryRecyclerView.setAdapter(consultationAdapter);
        medicationLogRecyclerView.setAdapter(medicationAdapter);
    }

    private void loadPatientData(int patientId) {
        if (patientId == -1) {
            return;
        }

        // Fetch data from the database
        Patient patient = dbHelper.getPatientById(patientId);
        List<Consultation> consultations = dbHelper.getConsultationsByPatientId(patientId);
        List<Medication> medications = dbHelper.getMedicationsByPatientId(patientId);

        // Update adapters with data
        if (patient != null) {
            patientName = patient.getName();
            patientDetailsAdapter.updateData(Collections.singletonList(patient));
        }
        consultationAdapter.updateData(consultations);
        medicationAdapter.updateData(medications);
    }


}
