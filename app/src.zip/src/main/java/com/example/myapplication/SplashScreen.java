package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashScreen extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen);

        ImageView logo = findViewById(R.id.logo);
        TextView text1 = findViewById(R.id.splash_text1);
        TextView text2 = findViewById(R.id.splash_text2);

        // Load the animation
        Animation scaleRotateAnimation = AnimationUtils.loadAnimation(this, R.anim.scale_rotate);
        logo.startAnimation(scaleRotateAnimation);

        // Animate text after logo animation
        new Handler().postDelayed(() -> {
            text1.setAlpha(1);
            text1.animate().translationY(-30).setDuration(1000).start();

            new Handler().postDelayed(() -> {
                text2.setAlpha(1);
                text2.animate().translationY(-30).setDuration(1000).start();
            }, 500);
        }, 1500);

        // Transition to MainActivity after animation
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(SplashScreen.this, MainActivity.class);
            startActivity(intent);
            finish();
        }, 3000);
    }
}
