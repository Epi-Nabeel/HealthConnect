package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import java.util.ArrayList;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.widget.SearchView;

import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PatientsActivity extends AppCompatActivity implements PatientsAdapter.OnPatientListener {
    private RecyclerView recyclerView;
    private PatientsAdapter adapter;
    private List<Patient> patients;
    private DatabaseHelper db;
    private SearchView searchView;
    private Button btnAddPatient;
    private ActivityResultLauncher<Intent> addPatientLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.patient_records);

        // ImageButton Click Handlers
        ImageButton btnPatientRecordsImg = findViewById(R.id.btn_patient_records);
        btnPatientRecordsImg.setOnClickListener(view -> {
            Intent intent = new Intent(PatientsActivity.this, PatientsActivity.class);
            startActivity(intent);
        });

        ImageButton btnConsultationImg = findViewById(R.id.btn_consultation);
        btnConsultationImg.setOnClickListener(view -> {
            Intent intent = new Intent(PatientsActivity.this, ConsultationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnMedicalTrackingImg = findViewById(R.id.btn_medical_tracking);
        btnMedicalTrackingImg.setOnClickListener(view -> {
            Intent intent = new Intent(PatientsActivity.this, MedicationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnAppointmentsImg = findViewById(R.id.btn_appointments);
        btnAppointmentsImg.setOnClickListener(view -> {
            Intent intent = new Intent(PatientsActivity.this, AppointmentsActivity.class);
            startActivity(intent);
        });

        ImageButton btnReportsImg = findViewById(R.id.btn_reports);
        btnReportsImg.setOnClickListener(view -> {
            Intent intent = new Intent(PatientsActivity.this, MedicineListActivity.class);
            startActivity(intent);
        });

        addPatientLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        List<Patient> patient = db.getAllPatients();
                        adapter.updateList(patient);
                    }
                }
        );

        btnAddPatient = findViewById(R.id.btn_add_patient);
        searchView = findViewById(R.id.searchView);
        recyclerView = findViewById(R.id.recycler_view_patients);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        db = new DatabaseHelper(this);
        patients = db.getAllPatients();  // Get patients from DB
        adapter = new PatientsAdapter(this, patients, this);
        recyclerView.setAdapter(adapter);
        // Initialize and configure SearchView
        searchView = findViewById(R.id.searchView);
        searchView.setImeOptions(EditorInfo.IME_ACTION_DONE); // Close keyboard on "Done"
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false; // Not handling the submit action
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);
                return true;
            }
        });

        btnAddPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PatientsActivity.this, AddPatientActivity.class);
                addPatientLauncher.launch(intent);
            }
        });
    }

    // Method to filter patient list based on search query
    private void filterList(String query) {
        List<Patient> filteredList = new ArrayList<>();
        for (Patient patient : patients) {
            if (patient.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(patient);
            }
        }
        adapter.updateList(filteredList); // Update the adapter with filtered data
    }
    @Override
    public void onPatientClick(int position) {
        // Intent to open Patient Details Activity
        Intent intent = new Intent(PatientsActivity.this, PatientDetailsActivity.class);
        intent.putExtra("patient_id", patients.get(position).getId());
        startActivity(intent);
    }

    @Override
    public void onDeleteClick(int position) {
        db.deletePatient(patients.get(position).getId());
        patients.remove(position);  // Update the list
        adapter.notifyItemRemoved(position);
    }

}
