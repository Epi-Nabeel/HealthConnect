package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ConsultationAdapter extends RecyclerView.Adapter<ConsultationAdapter.ConsultationViewHolder> {
    private Context mContext;
    private List<Consultation> mConsultations; // List of consultation objects
    private boolean showPatientName;

    public ConsultationAdapter(Context context, List<Consultation> consultations, boolean showPatientName) {
        mContext = context;
        mConsultations = consultations;
        this.showPatientName = showPatientName;
    }

    @NonNull
    @Override
    public ConsultationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.consultation_item, parent, false);
        return new ConsultationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ConsultationViewHolder holder, int position) {
        Consultation consultation = mConsultations.get(position);
        if (showPatientName) {
            holder.patientName.setVisibility(View.VISIBLE); // Show patient name
            holder.patientName.setText(consultation.getPatientName());
        } else {
            holder.patientName.setVisibility(View.GONE); // Hide patient name
        }
        holder.patientName.setText(consultation.getPatientName());
        holder.consultationDate.setText("Consultation Date: " + consultation.getDate());
        holder.diagnosis.setText("Diagnosis: " + consultation.getDiagnosis());
        holder.treatment.setText("Treatment: " + consultation.getTreatment());
        holder.notes.setText("Doctor's Notes: " + consultation.getNotes());
    }

    @Override
    public int getItemCount() {
        return mConsultations.size();
    }

    public void updateData(List<Consultation> newData) {
        this.mConsultations.clear();
        this.mConsultations.addAll(newData);
        notifyDataSetChanged();
    }

    public static class ConsultationViewHolder extends RecyclerView.ViewHolder {
        public TextView patientName, consultationDate, diagnosis, treatment, notes;

        public ConsultationViewHolder(View itemView) {
            super(itemView);
            patientName = itemView.findViewById(R.id.patientName);
            consultationDate = itemView.findViewById(R.id.consultationDate);
            diagnosis = itemView.findViewById(R.id.diagnosis);
            treatment = itemView.findViewById(R.id.treatment);
            notes = itemView.findViewById(R.id.notes);
        }
    }
}

