package com.example.myapplication;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AddMedicationActivity extends AppCompatActivity {

    private int patientId;
    TextInputEditText startDateInput;
    TextInputEditText endDateInput;
    AutoCompleteTextView drugInput;
    private DatabaseHelper databaseHelper;
    int selectedDrugId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_medication);

        // Get the passed patient ID and name
        Intent intent = getIntent();
        patientId = intent.getIntExtra("patient_id", -1);
        String patientName = intent.getStringExtra("patient_name");

        // Set patient name in the non-editable text field
        TextInputEditText nameInput = findViewById(R.id.addMed_patient_name_input);
        nameInput.setText(patientName);

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        startDateInput = findViewById(R.id.addMed_start_date_input);
        endDateInput = findViewById(R.id.addMed_end_date_input);

        startDateInput.setOnClickListener(v -> {
            new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                // Update the calendar and set the selected date in the input
                calendar.set(year, month, dayOfMonth);
                startDateInput.setText(dateFormat.format(calendar.getTime()));
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        endDateInput.setOnClickListener(v -> {
            new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                // Update the calendar and set the selected date in the input
                calendar.set(year, month, dayOfMonth);
                endDateInput.setText(dateFormat.format(calendar.getTime()));
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        MaterialButton submitButton = findViewById(R.id.addMed_submit_button);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveMedication();
            }
        });

        MaterialButton resetButton = findViewById(R.id.addMed_reset_button);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearForm();
            }
        });

        drugInput = findViewById(R.id.addMed_drug_input);
        databaseHelper = new DatabaseHelper(this);

        Map<String, Integer> drugMap = databaseHelper.getAllDrugNamesWithIds();
        List<String> drugNames = new ArrayList<>(drugMap.keySet());

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, drugNames);

        drugInput.setAdapter(adapter);

        drugInput.setOnItemClickListener((parent, view, position, id) -> {
            String selectedDrug = adapter.getItem(position);
            selectedDrugId = drugMap.get(selectedDrug);

            Toast.makeText(this, "Selected Drug ID: " + selectedDrugId, Toast.LENGTH_SHORT).show();
        });

    }

    private void saveMedication() {

        // Get references to input fields
        drugInput = findViewById(R.id.addMed_drug_input);
        TextInputEditText dosageInput = findViewById(R.id.addMed_dosage_input);
        TextInputEditText startDateInput = findViewById(R.id.addMed_start_date_input);
        TextInputEditText endDateInput = findViewById(R.id.addMed_end_date_input);
        TextInputEditText additionalInsInput = findViewById(R.id.addMed_instructions_input);

        // Get input text as strings
        String drug = drugInput.getText().toString().trim();
        String dosage = dosageInput.getText().toString().trim();
        String startDate = startDateInput.getText().toString().trim();
        String endDate = endDateInput.getText().toString().trim();
        String instructions = additionalInsInput.getText().toString().trim();

        // Validate inputs
        if (drug.isEmpty()) {
            drugInput.setError("Please enter a drug name");
            drugInput.requestFocus();
            return;
        }

        if (dosage.isEmpty()) {
            dosageInput.setError("Please enter a dosage");
            dosageInput.requestFocus();
            return;
        }

        if (startDate.isEmpty()) {
            startDateInput.setError("Please enter a start date");
            startDateInput.requestFocus();
            return;
        }

        if (endDate.isEmpty()) {
            endDateInput.setError("Please enter an end date");
            endDateInput.requestFocus();
            return;
        }


        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        sdf.setLenient(false);
        try {
            sdf.parse(startDate);
        } catch (ParseException e) {
            startDateInput.setError("Invalid start date format. Use yyyy-MM-dd");
            startDateInput.requestFocus();
            return;
        }

        try {
            sdf.parse(endDate);
        } catch (ParseException e) {
            endDateInput.setError("Invalid end date format. Use yyyy-MM-dd");
            endDateInput.requestFocus();
            return;
        }

        try {
            Date start = sdf.parse(startDate);
            Date end = sdf.parse(endDate);
            if (start.after(end)) {
                endDateInput.setError("End date must be after start date");
                endDateInput.requestFocus();
                return;
            }
        } catch (ParseException e) {

        }


        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.addMedication(patientId, selectedDrugId, drug, dosage, startDate, endDate, instructions);

        Toast.makeText(this, "Patient Medication added successfully", Toast.LENGTH_SHORT).show();

        setResult(RESULT_OK);
        finish();
    }


    private void clearForm() {
        ((AutoCompleteTextView) findViewById(R.id.addMed_drug_input)).setText("");
        ((TextInputEditText) findViewById(R.id.addMed_dosage_input)).setText("");
        ((TextInputEditText) findViewById(R.id.addMed_instructions_input)).setText("");
        ((TextInputEditText) findViewById(R.id.addMed_start_date_input)).setText("");
        ((TextInputEditText) findViewById(R.id.addMed_end_date_input)).setText("");
    }


}
