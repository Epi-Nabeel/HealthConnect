package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PatientAdapter extends RecyclerView.Adapter<PatientAdapter.PatientViewHolder> {
    private List<String> patientNames;

    public PatientAdapter(List<String> patientNames) {
        this.patientNames = patientNames;
    }

    @NonNull
    @Override
    public PatientViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.patient_item, parent, false);
        return new PatientViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PatientViewHolder holder, int position) {
        String patientName = patientNames.get(position);
        holder.tvPatientName.setText(patientName);

        holder.btnDelete.setOnClickListener(v -> {
            patientNames.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, patientNames.size());
            //Need to delete from database
        });
    }

    @Override
    public int getItemCount() {
        return patientNames.size();
    }

    static class PatientViewHolder extends RecyclerView.ViewHolder {
        TextView tvPatientName;
        Button btnDelete;

        public PatientViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPatientName = itemView.findViewById(R.id.tv_patient_name);
            btnDelete = itemView.findViewById(R.id.btn_delete_patient);
        }
    }
}
