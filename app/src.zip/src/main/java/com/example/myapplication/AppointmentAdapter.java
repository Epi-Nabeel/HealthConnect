package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AppointmentAdapter extends RecyclerView.Adapter<AppointmentAdapter.AppointmentViewHolder> {

    private Context mContext;
    private List<Appointment> appointments;

    public AppointmentAdapter(Context context, List<Appointment> appointments) {
        this.mContext = context;
        this.appointments = appointments;
    }

    @NonNull
    @Override
    public AppointmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.appointment_item, parent, false);
        return new AppointmentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AppointmentViewHolder holder, int position) {
        Appointment appointment = appointments.get(position);
        holder.appointmentDate.setText("Date: " + appointment.getDate());
        holder.appointmentPatientName.setText("Patient: " + appointment.getName());
        holder.appointmentEmail.setText("Email: " + appointment.getEmail());
        holder.appointmentDescription.setText("Description: " + appointment.getDescription());
    }

    @Override
    public int getItemCount() {
        return appointments.size();
    }

    public void updateData(List<Appointment> newAppointments) {
        this.appointments.clear();
        this.appointments.addAll(newAppointments);
        notifyDataSetChanged();
    }

    static class AppointmentViewHolder extends RecyclerView.ViewHolder {
        TextView appointmentDate, appointmentPatientName, appointmentEmail, appointmentDescription;

        public AppointmentViewHolder(@NonNull View itemView) {
            super(itemView);
            appointmentDate = itemView.findViewById(R.id.appointmentDate);
            appointmentPatientName = itemView.findViewById(R.id.appointmentPatientName);
            appointmentEmail = itemView.findViewById(R.id.appointmentEmail);
            appointmentDescription = itemView.findViewById(R.id.appointmentDescription);
        }
    }
}
