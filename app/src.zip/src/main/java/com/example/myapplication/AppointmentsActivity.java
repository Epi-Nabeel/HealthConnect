package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AppointmentsActivity extends AppCompatActivity {

    private RecyclerView appointmentsRecyclerView;
    private AppointmentAdapter appointmentAdapter;
    private SearchView searchView;
    private Button btnBookAppointment;
    private DatabaseHelper dbHelper;
    private List<Appointment> appointmentsList; // Original list
    private List<Appointment> filteredAppointments; // For filtering results

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointment_list);

        // ImageButton Click Handlers
        ImageButton btnPatientRecordsImg = findViewById(R.id.btn_patient_records);
        btnPatientRecordsImg.setOnClickListener(view -> {
            Intent intent = new Intent(AppointmentsActivity.this, PatientsActivity.class);
            startActivity(intent);
        });

        ImageButton btnConsultationImg = findViewById(R.id.btn_consultation);
        btnConsultationImg.setOnClickListener(view -> {
            Intent intent = new Intent(AppointmentsActivity.this, ConsultationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnMedicalTrackingImg = findViewById(R.id.btn_medical_tracking);
        btnMedicalTrackingImg.setOnClickListener(view -> {
            Intent intent = new Intent(AppointmentsActivity.this, MedicationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnAppointmentsImg = findViewById(R.id.btn_appointments);
        btnAppointmentsImg.setOnClickListener(view -> {
            Intent intent = new Intent(AppointmentsActivity.this, AppointmentsActivity.class);
            startActivity(intent);
        });

        ImageButton btnReportsImg = findViewById(R.id.btn_reports);
        btnReportsImg.setOnClickListener(view -> {
            Intent intent = new Intent(AppointmentsActivity.this, MedicineListActivity.class);
            startActivity(intent);
        });

        // Initialize UI components
        appointmentsRecyclerView = findViewById(R.id.appointmentsRecyclerView);
        searchView = findViewById(R.id.searchViewAppointments);
        btnBookAppointment = findViewById(R.id.btnBookAppointment);
        dbHelper = new DatabaseHelper(this);

        // Load initial appointments from the database
        loadAppointments();

        // Set up RecyclerView
        filteredAppointments = new ArrayList<>(appointmentsList); // Initialize with all appointments
        appointmentAdapter = new AppointmentAdapter(this, filteredAppointments);
        appointmentsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        appointmentsRecyclerView.setAdapter(appointmentAdapter);

        // Search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false; // Not handling submit action
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterAppointments(newText);
                return true;
            }
        });

        // Book appointment button click
        btnBookAppointment.setOnClickListener(v -> {
            Intent intent = new Intent(AppointmentsActivity.this, BookAppointmentActivity.class);
            startActivityForResult(intent, 1); // Request code 1 for identifying new booking
        });
    }

    private void loadAppointments() {
        // Fetch all appointments from the database
        appointmentsList = dbHelper.getAllAppointments();
        if (appointmentsList == null) {
            appointmentsList = new ArrayList<>();
        }
    }

    private void filterAppointments(String query) {
        if (TextUtils.isEmpty(query)) {
            // Reset to full list when the search query is cleared
            filteredAppointments.clear();
            filteredAppointments.addAll(appointmentsList);
        } else {
            // Filter appointments based on the query
            List<Appointment> tempFilteredList = new ArrayList<>();
            for (Appointment appointment : appointmentsList) {
                if (appointment.getName().toLowerCase().contains(query.toLowerCase()) ||
                        appointment.getDescription().toLowerCase().contains(query.toLowerCase()) ||
                        appointment.getDate().toLowerCase().contains(query.toLowerCase())) {
                    tempFilteredList.add(appointment);
                }
            }

            filteredAppointments.clear();
            filteredAppointments.addAll(tempFilteredList);
        }

        // Notify adapter of data changes
        appointmentAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            // Reload appointments and update adapter in real-time
            loadAppointments();
            filteredAppointments.clear();
            filteredAppointments.addAll(appointmentsList);
            appointmentAdapter.notifyDataSetChanged();
        }
    }
}


