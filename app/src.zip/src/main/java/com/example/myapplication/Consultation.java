package com.example.myapplication;

public class Consultation {
    private String patientName;
    private String date;
    private String diagnosis;
    private String treatment;
    private String notes;
    private int patientid;

    public Consultation(String patientName, String date, String diagnosis, String treatment, String notes) {
        this.patientName = patientName;
        this.date = date;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
        this.notes = notes;
    }

    public Consultation(int patientid, String date, String diagnosis, String treatment, String notes) {
        this.patientid = patientid;
        this.date = date;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
        this.notes = notes;
    }

    // Getters
    public String getPatientName() {
        return patientName;
    }

    public String getDate() {
        return date;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public String getTreatment() {
        return treatment;
    }

    public String getNotes() {
        return notes;
    }

    public int getPatientid() {
        return patientid;
    }

    public void setPatientid(int patientid) {
        this.patientid = patientid;
    }
}

