package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MedicationAdapter extends RecyclerView.Adapter<MedicationAdapter.MedicationViewHolder> {
    private Context mContext;
    private List<Medication> mMedications; // List of consultation objects
    private boolean showPatientName;

    public MedicationAdapter(Context context, List<Medication> medications, boolean showPatientName) {
        mContext = context;
        mMedications = medications != null ? medications : new ArrayList<>();
        this.showPatientName = showPatientName;
    }


    @NonNull
    @Override
    public MedicationAdapter.MedicationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.medication_log_item, parent, false);
        return new MedicationAdapter.MedicationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MedicationAdapter.MedicationViewHolder holder, int position) {
        Medication medication = mMedications.get(position);
        if (showPatientName) {
            holder.patientName.setVisibility(View.VISIBLE); // Show patient name
            holder.patientName.setText("Patient: " + medication.getPatientName());
        } else {
            holder.patientName.setVisibility(View.GONE); // Hide patient name
        }
        holder.medicationName.setText("Medication: " + medication.getMedicationName());
        holder.dosage.setText("Dosage: " + medication.getDosage());
        holder.frequency.setText("Frequency: " + medication.getFrequency());
    }


    @Override
    public int getItemCount() {
        return mMedications.size();
    }

    public void updateData(List<Medication> newData) {
        this.mMedications.clear();
        this.mMedications.addAll(newData);
        notifyDataSetChanged();
    }

    public static class MedicationViewHolder extends RecyclerView.ViewHolder {
        public TextView patientName, medicationName, dosage, frequency;

        public MedicationViewHolder(View itemView) {
            super(itemView);
            patientName = itemView.findViewById(R.id.patientName);
            medicationName = itemView.findViewById(R.id.medicationName);
            dosage = itemView.findViewById(R.id.medicationDosage);
            frequency = itemView.findViewById(R.id.medicationFrequency);
        }
    }
}
