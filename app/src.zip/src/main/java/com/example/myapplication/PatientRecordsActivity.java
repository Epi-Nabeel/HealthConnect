package com.example.myapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class PatientRecordsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PatientAdapter adapter;
    private List<String> patientNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.patient_records);


        recyclerView = findViewById(R.id.recycler_view_patients);


        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        patientNames = new ArrayList<>();
        patientNames.add("John Doe");
        patientNames.add("Mahinda Rajapakse");
        patientNames.add("Ranil Wickramasinghe");
        patientNames.add("Jane Smith");


        adapter = new PatientAdapter(patientNames);


        recyclerView.setAdapter(adapter);
    }
}

