package com.example.myapplication;

public class Medication {

    private String patientName;
    private int medicationId;
    private int patientId;
    private String medicationName;
    private String dosage;
    private String frequency;

    public Medication(String medicationName, String dosage, String frequency){
        this.medicationName = medicationName;
        this.dosage = dosage;
        this.frequency = frequency;
    }

    public Medication(int medicationId, String medicationName, String dosage, String frequency){
        this.medicationId = medicationId;
        this.medicationName = medicationName;
        this.dosage = dosage;
        this.frequency = frequency;
    }

    public Medication(int id, String name, String dosage, String frequency, String patientName) {
        this.medicationId = id;
        this.medicationName = name;
        this.dosage = dosage;
        this.frequency = frequency;
        this.patientName = patientName;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getMedicationName() {return medicationName;}

    public String getDosage() {return dosage;}

    public String getFrequency(){return frequency;}

    public int getMedicationId(){
        return medicationId;
    }

    public void setMedicationId(int medicationId){
        this.medicationId = medicationId;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }


}
