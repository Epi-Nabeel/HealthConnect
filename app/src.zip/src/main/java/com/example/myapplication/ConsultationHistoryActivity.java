package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ConsultationHistoryActivity extends AppCompatActivity {
    private RecyclerView consultationsRecyclerView;
    private ConsultationAdapter consultationAdapter;
    private List<Consultation> consultationList;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.consult_history);

        // ImageButton Click Handlers
        ImageButton btnPatientRecordsImg = findViewById(R.id.btn_patient_records);
        btnPatientRecordsImg.setOnClickListener(view -> {
            Intent intent = new Intent(ConsultationHistoryActivity.this, PatientsActivity.class);
            startActivity(intent);
        });

        ImageButton btnConsultationImg = findViewById(R.id.btn_consultation);
        btnConsultationImg.setOnClickListener(view -> {
            Intent intent = new Intent(ConsultationHistoryActivity.this, ConsultationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnMedicalTrackingImg = findViewById(R.id.btn_medical_tracking);
        btnMedicalTrackingImg.setOnClickListener(view -> {
            Intent intent = new Intent(ConsultationHistoryActivity.this, MedicationHistoryActivity.class);
            startActivity(intent);
        });

        ImageButton btnAppointmentsImg = findViewById(R.id.btn_appointments);
        btnAppointmentsImg.setOnClickListener(view -> {
            Intent intent = new Intent(ConsultationHistoryActivity.this, AppointmentsActivity.class);
            startActivity(intent);
        });

        ImageButton btnReportsImg = findViewById(R.id.btn_reports);
        btnReportsImg.setOnClickListener(view -> {
            Intent intent = new Intent(ConsultationHistoryActivity.this, MedicineListActivity.class);
            startActivity(intent);
        });

        consultationsRecyclerView = findViewById(R.id.consultationsRecyclerView);
        consultationsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        dbHelper = new DatabaseHelper(this);

        // Fetch data from the database
        loadData();
    }

    private void loadData() {
        consultationList = dbHelper.getAllConsultations(); // Implement this method in DatabaseHelper
        consultationAdapter = new ConsultationAdapter(this, consultationList, true);
        consultationsRecyclerView.setAdapter(consultationAdapter);
    }
}
