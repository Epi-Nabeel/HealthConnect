package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddConsultationActivity extends AppCompatActivity {
    private int patientId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_consultation);

        // Get the passed patient ID and name
        Intent intent = getIntent();
        patientId = intent.getIntExtra("patient_id", -1);
        String patientName = intent.getStringExtra("patient_name");

        // Set patient name in the non-editable text field
        TextInputEditText nameInput = findViewById(R.id.patient_name_input);
        nameInput.setText(patientName);

        MaterialButton submitButton = findViewById(R.id.submit_button);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveConsultation();
            }
        });

        MaterialButton resetButton = findViewById(R.id.reset_button);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearForm();
            }
        });
    }

    private void saveConsultation() {

        TextInputEditText diagnosisInput = findViewById(R.id.diagnosis_input);
        TextInputEditText treatmentInput = findViewById(R.id.treatments_input);
        TextInputEditText notesInput = findViewById(R.id.notes_input);

        String diagnosis = diagnosisInput.getText().toString();
        String treatment = treatmentInput.getText().toString();
        String notes = notesInput.getText().toString();

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.addConsultation(patientId, getCurrentDate(), diagnosis, treatment, notes);

        Toast.makeText(this, "Consultation added successfully", Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
        finish();  // Close the activity and return to the previous screen
    }

    private void clearForm() {

        ((TextInputEditText) findViewById(R.id.diagnosis_input)).setText("");
        ((TextInputEditText) findViewById(R.id.treatments_input)).setText("");
        ((TextInputEditText) findViewById(R.id.notes_input)).setText("");
    }

    private String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return sdf.format(new Date());
    }
}

