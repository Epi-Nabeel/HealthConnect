package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookAppointmentActivity extends AppCompatActivity {
    private EditText nameInput, dateInput, emailInput, descriptionInput;
    private Button saveButton, resetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_appointment);

        nameInput = findViewById(R.id.app_name_input);
        dateInput = findViewById(R.id.app_date_input);
        emailInput = findViewById(R.id.app_email_input);
        descriptionInput = findViewById(R.id.app_description_input);
        saveButton = findViewById(R.id.app_save_button);
        resetButton = findViewById(R.id.app_reset_button);

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        dateInput.setOnClickListener(v -> {
            new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                // Update the calendar and set the selected date in the input
                calendar.set(year, month, dayOfMonth);
                dateInput.setText(dateFormat.format(calendar.getTime()));
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendEmailAndSaveAppointment();
            }
        });

        resetButton.setOnClickListener(view -> {
            nameInput.setText("");
            dateInput.setText("");
            emailInput.setText("");
            descriptionInput.setText("");
        });
    }

    private void sendEmailAndSaveAppointment() {
        EmailApiService service = RetrofitClientInstance.getRetrofitInstance().create(EmailApiService.class);
        EmailRequest request = new EmailRequest(
                emailInput.getText().toString(),
                "Appointment Confirmation",
                "Dear " + nameInput.getText().toString() + ",\nYour appointment is scheduled on " + dateInput.getText().toString() +
                        ".\nDetails: " + descriptionInput.getText().toString()
        );

        service.sendEmail(request).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    saveAppointmentToDatabase();
                    setResult(RESULT_OK);
                    finish();
                    Toast.makeText(BookAppointmentActivity.this, "Appointment booked and email sent!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(BookAppointmentActivity.this, "Failed to send email", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(BookAppointmentActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void saveAppointmentToDatabase() {
        // Implement the database insertion logic here
        DatabaseHelper db = new DatabaseHelper(this);
        db.addAppointment(new Appointment(
                nameInput.getText().toString(),
                dateInput.getText().toString(),
                emailInput.getText().toString(),
                descriptionInput.getText().toString()
        ));

        showNotification(
                "Appointment Booked",
                "Patient: " + nameInput.getText().toString() +
                        "\nDate: " + dateInput.getText().toString()
        );
    }

    @SuppressLint("MissingPermission")
    private void showNotification(String title, String message) {
        // Create a notification channel (required for Android 8.0+)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            String channelId = "appointment_channel";
            String channelName = "Appointment Notifications";
            NotificationChannel channel = new NotificationChannel(
                    channelId, channelName, NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Notifications for booked appointments");
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "appointment_channel")
                .setSmallIcon(R.drawable.ic_launcher_background) // Replace with your app's icon
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message)) // For multiline text
                .setPriority(NotificationCompat.PRIORITY_HIGH) // Priority for Android < 8.0
                .setAutoCancel(true); // Dismiss the notification on click

        // Show the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(1, builder.build());
    }

}
