package com.example.myapplication;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class EditPatientDetailsActivity extends AppCompatActivity {

    private TextInputEditText firstNameInput, lastNameInput, dobInput, phoneInput, emailInput, addressInput, emergencyContactInput;
    private RadioGroup genderGroup;
    private RadioButton maleRadio, femaleRadio, otherRadio;
    private MaterialButton saveButton, resetButton;

    private int patientId; // To store the patient's ID
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_patient); // Reusing the same layout

        // Initialize views
        firstNameInput = findViewById(R.id.patient_FirstName_input);
        lastNameInput = findViewById(R.id.patient_LastName_input);
        dobInput = findViewById(R.id.dob_input);
        phoneInput = findViewById(R.id.phone_input);
        emailInput = findViewById(R.id.email_input);
        addressInput = findViewById(R.id.address_input);
        emergencyContactInput = findViewById(R.id.emergency_contact_input);

        genderGroup = findViewById(R.id.gender_group);
        maleRadio = findViewById(R.id.male_radio);
        femaleRadio = findViewById(R.id.female_radio);
        otherRadio = findViewById(R.id.other_radio);

        saveButton = findViewById(R.id.save_button);
        resetButton = findViewById(R.id.reset_button);

        dbHelper = new DatabaseHelper(this);

        // Retrieve patient_id passed from the previous activity
        patientId = getIntent().getIntExtra("patient_id", -1);

        // Load patient details
        loadPatientDetails();

        // Date Picker for DOB input
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        dobInput.setOnClickListener(v -> {
            new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                calendar.set(year, month, dayOfMonth);
                dobInput.setText(dateFormat.format(calendar.getTime()));
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        // Save button to update the patient record
        saveButton.setOnClickListener(view -> {
            if (updatePatientDetails()) { // Update the database with new details
                Intent resultIntent = new Intent();
                resultIntent.putExtra("updated_patient_id", patientId); // Pass the patient ID back
                setResult(RESULT_OK, resultIntent); // Set the result with OK status
                finish(); // Close the activity
            } else {
                Toast.makeText(this, "Failed to update patient details", Toast.LENGTH_SHORT).show();
            }
        });

        // Reset button to reload current details
        resetButton.setOnClickListener(v -> loadPatientDetails());
    }

    private void loadPatientDetails() {
        if (patientId == -1) {
            Toast.makeText(this, "Invalid Patient ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Fetch patient details from the database
        Patient patient = dbHelper.getPatientByIdEdit(patientId);
        if (patient != null) {
            firstNameInput.setText(patient.getFirstName());
            lastNameInput.setText(patient.getLastName());
            dobInput.setText(patient.getDateOfBirth());
            phoneInput.setText(patient.getPhoneNumber());
            emailInput.setText(patient.getEmail());
            addressInput.setText(patient.getAddress());
            emergencyContactInput.setText(patient.getEmergencyContact());

            // Set gender
            switch (patient.getGender().toLowerCase()) {
                case "male":
                    maleRadio.setChecked(true);
                    break;
                case "female":
                    femaleRadio.setChecked(true);
                    break;
                case "other":
                    otherRadio.setChecked(true);
                    break;
            }
        }
    }

    private boolean updatePatientDetails() {
        String firstName = firstNameInput.getText().toString();
        String lastName = lastNameInput.getText().toString();
        String dob = dobInput.getText().toString();
        String gender = genderGroup.getCheckedRadioButtonId() == R.id.male_radio ? "Male" :
                genderGroup.getCheckedRadioButtonId() == R.id.female_radio ? "Female" : "Other";
        String phoneNumber = phoneInput.getText().toString();
        String email = emailInput.getText().toString();
        String address = addressInput.getText().toString();
        String emergencyContact = emergencyContactInput.getText().toString();

        return dbHelper.updatePatient(new Patient(
                patientId,
                firstName,
                lastName,
                dob,
                gender,
                phoneNumber,
                email,
                address,
                emergencyContact
        ));
    }
}
