package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "HealthConnect.db";
    private static final int DATABASE_VERSION = 4;

    // patients
    private static final String CREATE_TABLE_PATIENTS =
            "CREATE TABLE IF NOT EXISTS patients (" +
                    "patient_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "first_name TEXT," +
                    "last_name TEXT," +
                    "dob TEXT," + // storing date as text in SQLite
                    "gender TEXT," +
                    "phone_number TEXT," +
                    "email TEXT," +
                    "address TEXT," +
                    "emergency_contact TEXT" +
                    ");";

    // Consultations
    private static final String CREATE_TABLE_CONSULTATIONS =
            "CREATE TABLE IF NOT EXISTS consultations (" +
                    "consultation_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "patient_id INTEGER," +
                    "date TEXT," +
                    "diagnosis TEXT," +
                    "notes TEXT," +
                    "treatment TEXT," +
                    "FOREIGN KEY(patient_id) REFERENCES patients(patient_id)" +
                    ");";

    // Medications
    private static final String CREATE_TABLE_MEDICATIONS =
            "CREATE TABLE IF NOT EXISTS medications (" +
                    "medication_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "name TEXT," +
                    "dosage TEXT," +
                    "frequency TEXT" +
                    ");";

    // Medications
    private static final String CREATE_TABLE_PATIENT_MEDICATIONS =
            "CREATE TABLE IF NOT EXISTS patient_medications (" +
                    "record_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "patient_id INTEGER," +
                    "medication_id INTEGER," +
                    "start_date TEXT," +
                    "end_date TEXT," +
                    "notes TEXT," +
                    "FOREIGN KEY(patient_id) REFERENCES patients(patient_id)," +
                    "FOREIGN KEY(medication_id) REFERENCES medications(medication_id)" +
                    ");";

    // Appointments
    private static final String CREATE_TABLE_APPOINTMENTS =
            "CREATE TABLE IF NOT EXISTS appointments (" +
                    "appointment_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "name TEXT, " +
                    "appointment_date TEXT," +
                    "email TEXT," +
                    "description TEXT" +
                    ");";

    private static final String CREATE_TABLE_GENERAL_MEDICINES =
            "CREATE TABLE general_medicines (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT NOT NULL, " +
                    "description TEXT, " +
                    "price REAL);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_PATIENTS);
        db.execSQL(CREATE_TABLE_CONSULTATIONS);
        db.execSQL(CREATE_TABLE_MEDICATIONS);
        db.execSQL(CREATE_TABLE_PATIENT_MEDICATIONS);
        db.execSQL(CREATE_TABLE_APPOINTMENTS);
        db.execSQL(CREATE_TABLE_GENERAL_MEDICINES);

        insertDummyPatients(db);
        insertDummyMedications(db);
        insertDummyAppointments(db);
        insertDummyConsultations(db);
        insertDummyPatientMedications(db);
        insertDummyGeneralMedicines(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // On upgrade drop older tables
        db.execSQL("DROP TABLE IF EXISTS patients");
        db.execSQL("DROP TABLE IF EXISTS consultations");
        db.execSQL("DROP TABLE IF EXISTS medications");
        db.execSQL("DROP TABLE IF EXISTS patient_medications");
        db.execSQL("DROP TABLE IF EXISTS appointments");
        db.execSQL("DROP TABLE IF EXISTS general_medicines");
        onCreate(db);

        if (oldVersion < 2) {
//            db.execSQL("ALTER TABLE consultations ADD COLUMN treatment TEXT");
        }
    }

    private void insertDummyPatients(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put("first_name", "John");
        values.put("last_name", "Doe");
        values.put("dob", "1990-01-01");
        values.put("gender", "Male");
        values.put("phone_number", "1234567890");
        values.put("email", "john.doe@example.com");
        values.put("address", "123 Elm St");
        values.put("emergency_contact", "Jane Doe");
        db.insert("patients", null, values);

        values.clear();
        values.put("first_name", "Jane");
        values.put("last_name", "Smith");
        values.put("dob", "1985-05-05");
        values.put("gender", "Female");
        values.put("phone_number", "0987654321");
        values.put("email", "jane.smith@example.com");
        values.put("address", "456 Oak St");
        values.put("emergency_contact", "John Smith");
        db.insert("patients", null, values);
    }

    private void insertDummyMedications(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put("name", "Amoxicillin");
        values.put("dosage", "500mg");
        values.put("frequency", "Every 8 hours");
        db.insert("medications", null, values);

        values.clear();
        values.put("name", "Ibuprofen");
        values.put("dosage", "200mg");
        values.put("frequency", "Every 6 hours");
        db.insert("medications", null, values);
    }

    private void insertDummyAppointments(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put("appointment_date", "2021-12-10");
        values.put("name", "Jones");
        values.put("email", "Routine Checkup");
        values.put("description", "Annual physical exam");
        db.insert("appointments", null, values);

        values.clear();
        values.put("appointment_date", "2021-12-12");
        values.put("name", "Bones");
        values.put("email", "Routine Checkup");
        values.put("description", "Annual physical exam");
        db.insert("appointments", null, values);
    }

    private void insertDummyConsultations(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put("patient_id", 1);
        values.put("date", "2021-12-10");
        values.put("diagnosis", "Routine checkup");
        values.put("notes", "No issues noted.");
        values.put("treatment", "Break the leg");
        db.insert("consultations", null, values);

        values.clear();
        values.put("patient_id", 2);
        values.put("date", "2021-12-11");
        values.put("diagnosis", "Common cold");
        values.put("notes", "Prescribed rest and hydration.");
        values.put("treatment", "Break the right leg");
        db.insert("consultations", null, values);
    }

    private void insertDummyPatientMedications(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put("patient_id", 1);
        values.put("medication_id", 1);  // Assuming MedicationID 1 is for Amoxicillin
        values.put("start_date", "2021-12-10");
        values.put("end_date", "2021-12-20");
        values.put("notes", "Take three times a day after meals.");
        db.insert("patient_medications", null, values);

        values.clear();
        values.put("patient_id", 2);
        values.put("medication_id", 2);  // Assuming MedicationID 2 is for Ibuprofen
        values.put("start_date", "2021-12-11");
        values.put("end_date", "2021-12-18");
        values.put("notes", "Take as needed for pain up to 4 times a day.");
        db.insert("patient_medications", null, values);
    }

    private void insertDummyGeneralMedicines(SQLiteDatabase db) {
        ContentValues values = new ContentValues();

        values.put("name", "Paracetamol");
        values.put("description", "Used to reduce fever and relieve mild to moderate pain.");
        values.put("price", 10.0);
        db.insert("general_medicines", null, values);

        values.clear();
        values.put("name", "Ibuprofen");
        values.put("description", "Non-steroidal anti-inflammatory drug for pain relief.");
        values.put("price", 15.0);
        db.insert("general_medicines", null, values);
    }

    public List<Consultation> getAllConsultations() {
        List<Consultation> consultations = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT p.first_name, p.last_name, c.date, c.diagnosis, c.treatment, c.notes FROM consultations c INNER JOIN patients p ON c.patient_id = p.patient_id", null);

        int firstNameIndex = cursor.getColumnIndex("first_name");
        int lastNameIndex = cursor.getColumnIndex("last_name");
        int dateIndex = cursor.getColumnIndex("date");
        int diagnosisIndex = cursor.getColumnIndex("diagnosis");
        int treatmentIndex = cursor.getColumnIndex("treatment");
        int notesIndex = cursor.getColumnIndex("notes");

        if (cursor.moveToFirst()) {
            do {
                if (firstNameIndex != -1 && lastNameIndex != -1 && dateIndex != -1 && diagnosisIndex != -1 && treatmentIndex != -1 && notesIndex != -1) {
                    String patientName = cursor.getString(firstNameIndex) + " " + cursor.getString(lastNameIndex);
                    String date = cursor.getString(dateIndex);
                    String diagnosis = cursor.getString(diagnosisIndex);
                    String treatment = cursor.getString(treatmentIndex);
                    String notes = cursor.getString(notesIndex);

                    consultations.add(new Consultation(patientName, date, diagnosis, treatment, notes));
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return consultations;
    }

    public List<Medication> getAllMedicationsWithPatients() {
        List<Medication> medicationList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Join query to fetch medication details along with patient names
        String query = "SELECT m.medication_id, m.name AS medication_name, m.dosage, m.frequency, " +
                "p.first_name || ' ' || p.last_name AS patient_name " +
                "FROM medications m " +
                "INNER JOIN patient_medications pm ON m.medication_id = pm.medication_id " +
                "INNER JOIN patients p ON pm.patient_id = p.patient_id";

        Cursor cursor = db.rawQuery(query, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int medicationId = cursor.getInt(cursor.getColumnIndexOrThrow("medication_id"));
                String medicationName = cursor.getString(cursor.getColumnIndexOrThrow("medication_name"));
                String dosage = cursor.getString(cursor.getColumnIndexOrThrow("dosage"));
                String frequency = cursor.getString(cursor.getColumnIndexOrThrow("frequency"));
                String patientName = cursor.getString(cursor.getColumnIndexOrThrow("patient_name"));

                // Create Medication object with patient name
                medicationList.add(new Medication(medicationId, medicationName, dosage, frequency, patientName));
            } while (cursor.moveToNext());
            cursor.close();
        }

        db.close();
        return medicationList;
    }


    public void addConsultation(int patientId, String date, String diagnosis, String treatment, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("patient_id", patientId);
        values.put("date", date);
        values.put("diagnosis", diagnosis);
        values.put("treatment", treatment);
        values.put("notes", notes);

        db.insert("consultations", null, values);
        db.close();
    }

    public void addAppointment(Appointment appointment) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", appointment.getName());
        values.put("appointment_date", appointment.getDate());
        values.put("email", appointment.getEmail());
        values.put("description", appointment.getDescription());

        db.insert("appointments", null, values);
        db.close();
    }

    public void addMedication(int patientId, int drugId, String drug, String dosage, String startDate, String endDate, String instructions){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("patient_id", patientId);
        values.put("medication_id", drugId);
        values.put("start_date", startDate);
        values.put("end_date", endDate);
        values.put("notes", instructions);

        db.insert("patient_medications",null,values);
        db.close();

    }

    public  void addMedicine(String medicineName, String medDescription, double medicinePrice){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", medicineName);
        values.put("description", medDescription);
        values.put("price", medicinePrice);

        db.insert("general_medicines",null,values);
        db.close();


    }

    public void addPatient(String firstName, String lastName, String dob, String gender, String phoneNumber, String email, String address, String emergencyContact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("first_name", firstName);
        values.put("last_name", lastName);
        values.put("dob", dob);
        values.put("gender", gender);
        values.put("phone_number", phoneNumber);
        values.put("email", email);
        values.put("address", address);
        values.put("emergency_contact", emergencyContact);

        db.insert("patients", null, values); // Insert values into the "patients" table
        db.close();
    }




//    public List<Appointment> getAllAppointments() {
//        List<Appointment> appointments = new ArrayList<>();
//        String selectQuery = "SELECT * FROM appointments";
//        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor cursor = db.rawQuery(selectQuery, null);
//
//        if (cursor.moveToFirst()) {
//            do {
//                Appointment appointment = new Appointment(
//                        cursor.getInt(cursor.getColumnIndex("id")),
//                        cursor.getString(cursor.getColumnIndex("name")),
//                        cursor.getString(cursor.getColumnIndex("date")),
//                        cursor.getString(cursor.getColumnIndex("email")),
//                        cursor.getString(cursor.getColumnIndex("description"))
//                );
//                appointments.add(appointment);
//            } while (cursor.moveToNext());
//        }
//        cursor.close();
//        db.close();
//        return appointments;
//    }

    public List<Appointment> getAllAppointments() {
        List<Appointment> appointments = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT appointment_id, name, appointment_date, email, description FROM appointments";

        Cursor cursor = db.rawQuery(query, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int appointmentId = cursor.getInt(cursor.getColumnIndex("appointment_id"));
                @SuppressLint("Range") String patientName = cursor.getString(cursor.getColumnIndex("name"));
                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex("appointment_date"));
                @SuppressLint("Range") String email = cursor.getString(cursor.getColumnIndex("email"));
                @SuppressLint("Range") String description = cursor.getString(cursor.getColumnIndex("description"));

                appointments.add(new Appointment(appointmentId, patientName, date, email,  description));
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }

        return appointments;
    }



    public List<Patient> getAllPatients() {
        List<Patient> patients = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("patients", null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("patient_id")); // Note the correct column name here
                @SuppressLint("Range") String firstName = cursor.getString(cursor.getColumnIndex("first_name"));
                @SuppressLint("Range") String lastName = cursor.getString(cursor.getColumnIndex("last_name"));
                String fullName = firstName + " " + lastName;
                @SuppressLint("Range") String dateOfBirth = cursor.getString(cursor.getColumnIndex("dob"));
                @SuppressLint("Range") String gender = cursor.getString(cursor.getColumnIndex("gender"));
                @SuppressLint("Range") String phoneNumber = cursor.getString(cursor.getColumnIndex("phone_number"));
                @SuppressLint("Range") String email = cursor.getString(cursor.getColumnIndex("email"));
                @SuppressLint("Range") String address = cursor.getString(cursor.getColumnIndex("address"));
                @SuppressLint("Range") String emergencyContact = cursor.getString(cursor.getColumnIndex("emergency_contact"));

                patients.add(new Patient(id, fullName, dateOfBirth, gender, phoneNumber, email, address, emergencyContact));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return patients;
    }


    public void deletePatient(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            int result = db.delete("patients", "patient_id = ?", new String[]{String.valueOf(id)});
        } catch (Exception e) {
        } finally {
            db.close();
        }
    }

    public Patient getPatientById(int patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Patient patient = null;
        Patient editPatient = null;
        Cursor cursor = db.query(
                "patients",
                null,
                "patient_id = ?",
                new String[]{String.valueOf(patientId)},
                null,
                null,
                null);

        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") String firstName = cursor.getString(cursor.getColumnIndex("first_name"));
            @SuppressLint("Range") String lastName = cursor.getString(cursor.getColumnIndex("last_name"));
            @SuppressLint("Range") String dob = cursor.getString(cursor.getColumnIndex("dob"));
            @SuppressLint("Range") String gender = cursor.getString(cursor.getColumnIndex("gender"));
            @SuppressLint("Range") String phoneNumber = cursor.getString(cursor.getColumnIndex("phone_number"));
            @SuppressLint("Range") String email = cursor.getString(cursor.getColumnIndex("email"));
            @SuppressLint("Range") String address = cursor.getString(cursor.getColumnIndex("address"));
            @SuppressLint("Range") String emergencyContact = cursor.getString(cursor.getColumnIndex("emergency_contact"));

            String fullName = firstName + " " + lastName;
            patient = new Patient(patientId, fullName, dob, gender, phoneNumber, email, address, emergencyContact);
            editPatient = new Patient(patientId, firstName, lastName, dob, gender, phoneNumber, email, address, emergencyContact);
        }

        if (cursor != null) {
            cursor.close();
        }
        return patient;
    }

    public Patient getPatientByIdEdit(int patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Patient editPatient = null;
        Cursor cursor = db.query(
                "patients",
                null,
                "patient_id = ?",
                new String[]{String.valueOf(patientId)},
                null,
                null,
                null);

        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") String firstName = cursor.getString(cursor.getColumnIndex("first_name"));
            @SuppressLint("Range") String lastName = cursor.getString(cursor.getColumnIndex("last_name"));
            @SuppressLint("Range") String dob = cursor.getString(cursor.getColumnIndex("dob"));
            @SuppressLint("Range") String gender = cursor.getString(cursor.getColumnIndex("gender"));
            @SuppressLint("Range") String phoneNumber = cursor.getString(cursor.getColumnIndex("phone_number"));
            @SuppressLint("Range") String email = cursor.getString(cursor.getColumnIndex("email"));
            @SuppressLint("Range") String address = cursor.getString(cursor.getColumnIndex("address"));
            @SuppressLint("Range") String emergencyContact = cursor.getString(cursor.getColumnIndex("emergency_contact"));

            editPatient = new Patient(patientId, firstName, lastName, dob, gender, phoneNumber, email, address, emergencyContact);
        }

        if (cursor != null) {
            cursor.close();
        }
        return editPatient;
    }

    public List<Consultation> getConsultationsByPatientId(int patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Consultation> consultations = new ArrayList<>();

        Cursor cursor = db.query(
                "consultations",
                null,
                "patient_id = ?",
                new String[]{String.valueOf(patientId)},
                null,
                null,
                "date DESC"); // Order by most recent

        if (cursor != null && cursor.moveToFirst()) {
            do {

                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex("date"));
                @SuppressLint("Range") String diagnosis = cursor.getString(cursor.getColumnIndex("diagnosis"));
                @SuppressLint("Range") String treatment = cursor.getString(cursor.getColumnIndex("treatment"));
                @SuppressLint("Range") String notes = cursor.getString(cursor.getColumnIndex("notes"));

                consultations.add(new Consultation(patientId, date, diagnosis, treatment, notes));
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }
        return consultations;
    }

    public List<Medication> getMedicationsByPatientId(int patientId) {
        List<Medication> medicationList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to fetch medication details for a specific patient
        String query = "SELECT m.medication_id, m.name AS medication_name, m.dosage, m.frequency " +
                "FROM medications m " +
                "INNER JOIN patient_medications pm ON m.medication_id = pm.medication_id " +
                "WHERE pm.patient_id = ?";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(patientId)});

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int medicationId = cursor.getInt(cursor.getColumnIndexOrThrow("medication_id"));
                String medicationName = cursor.getString(cursor.getColumnIndexOrThrow("medication_name"));
                String dosage = cursor.getString(cursor.getColumnIndexOrThrow("dosage"));
                String frequency = cursor.getString(cursor.getColumnIndexOrThrow("frequency"));

                // Create Medication object without patient name
                medicationList.add(new Medication(medicationId, medicationName, dosage, frequency));
            } while (cursor.moveToNext());
            cursor.close();
        }

        db.close();
        return medicationList;
    }



    public List<Medicine> getAllGeneralMedicines() {
        List<Medicine> medicineList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM general_medicines";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                double price = cursor.getDouble(cursor.getColumnIndexOrThrow("price"));

                medicineList.add(new Medicine(id, name, description, price));
            } while (cursor.moveToNext());
            cursor.close();
        }

        db.close();
        return medicineList;
    }

    public Map<String, Integer> getAllDrugNamesWithIds() {
        Map<String, Integer> drugMap = new HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT id, name FROM general_medicines";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                drugMap.put(name, id);
            } while (cursor.moveToNext());
            cursor.close();
        }

        db.close();
        return drugMap;
    }


    public boolean updatePatient(Patient patient) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("first_name", patient.getFirstName());
        values.put("last_name", patient.getLastName());
        values.put("dob", patient.getDateOfBirth());
        values.put("gender", patient.getGender());
        values.put("phone_number", patient.getPhoneNumber());
        values.put("email", patient.getEmail());
        values.put("address", patient.getAddress());
        values.put("emergency_contact", patient.getEmergencyContact());

        int rowsAffected = db.update("patients", values, "patient_id = ?", new String[]{String.valueOf(patient.getId())});
        db.close();

        return rowsAffected > 0;
    }



}
